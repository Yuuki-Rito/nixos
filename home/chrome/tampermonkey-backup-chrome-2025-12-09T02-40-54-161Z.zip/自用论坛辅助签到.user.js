// ==UserScript==
// @name         自用论坛辅助签到
// @namespace    bbshelper
// @version      9.0.1
// @description  x
// @author       lazycat
// @include        *://www.tsdm*.*/*
// @include        *://www.hanbao520*.*/*
// @include        *://zxcstxt.*/*
// @include        *://zxcsol.*/*
// @include        *://live.bilibili.com/*
// @grant        unsafeWindow
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM.deleteValue
// @require      https://cdn.jsdelivr.net/npm/jquery@3.5.0/dist/jquery.min.js
// @run-at 		 document-end
// ==/UserScript==

(function () {
    // 日期格式化
    Date.prototype.format = function (fmt) {
        const o = {
            "M+": this.getMonth() + 1,                 //月份
            "d+": this.getDate(),                    //日
            "h+": this.getHours(),                   //小时
            "m+": this.getMinutes(),                 //分
            "s+": this.getSeconds(),                 //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds()             //毫秒
        };
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substring(4 - RegExp.$1.length));
        }
        for (const k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substring(("" + o[k]).length)));
            }
        }
        return fmt;
    }

    let variableName;
    window.onload = async function waitForSelector() {
        // deleteStorageData("BBSSignHelperData");
        // return;
        for (let index = 0; index < 6; index++) {
            await new Promise((resolve) => {
                setTimeout(resolve, 3000);
            });
            console.log(index + "..........." + qd());
            if (qd()) {
                setSignData(variableName);
                return true;
            }
        }
        return false;

    };

    function qd() {
        if (matchURL("tsdm")) {
            variableName = "tsdmqd";
        } else if (matchURL("hanbao520")) {
            variableName = "qzbjqd";
        } else if (matchURL("zxcstxt")||matchURL("zxcsol")) {
            variableName = "zxcsqd";
        } else if (matchURL("bilibili")) {
            variableName = "bzqd";
        }
        if (checkSignDate(variableName)) {
            return true;
        }
        return eval(variableName + '()');
    }


    // 天使动漫
    function tsdmqd() {
        if (matchURL('dsu_paulsign:sign')) {
            if (window.find("今天签到了吗") && window.find("写下今天最想说的话")) {
                $("#wl_s").attr('checked', true);
                $("#todaysay").val("每天签到水一发。。。");
                $("#qiandao").submit();
                return true;
            }
        } else if (window.find("签到领奖!")) {
            window.location.href = "plugin.php?id=dsu_paulsign:sign";
        }
        return false;
    }

    // 轻之笔记
    function qzbjqd() {
        if (!matchURL('149713')) {
            window.location.href = "/149713";
        } else if (matchURL('149713')) {
            if (document.querySelector("#b2-widget-mission-2").querySelector(".b2font.b2-gift-2-line") != null) {
                $("#b2-widget-mission-2").find(".b2font.b2-gift-2-line").click();
                return true;
            } 
        }
        return false;
    }

    // 知轩藏书
    function zxcsqd() {
        const selector = $(".user-content").find("a")[0];
        if (selector != null && selector.text === "签到") {
            selector.click();
        } 
        return true;

    }

    // B站
    function bzqd() {
        // window.open("https://api.live.bilibili.com/xlive/web-ucenter/v1/sign/DoSign");
        $(".checkin-btn.t-center.pointer").click();
        if($(".checkin-btn.t-center.pointer") == null){
            return true;
        }
    }

    function matchURL(x) {
        return window.location.href.indexOf(x) !== -1;
    }


    // 判断上次签到日期
    const checkSignDate = function (name) {
        const lastSignDate = getData(name);
        if (lastSignDate != null) {
            return compareDate(new Date().format("yyyy-MM-dd"), lastSignDate);
        }
        return false
    }

    // 比较日期大小
    function compareDate(date1, date2) {
        const d1 = new Date(date1);
        const d2 = new Date(date2);
        return d2.getTime() >= d1.getTime();
    }

    function getStorageData() {
        return GM_getValue('BBSSignHelperData') ?? {};
    }

    function getData(key) {
        return getStorageData()[key];
    }

    function setData(key, value) {
        const data = getStorageData();
        data[key] = value;
        GM_setValue('BBSSignHelperData', data);
    }

    function setSignData(variableName) {
        setData(variableName, new Date().format("yyyy-MM-dd"));
    }

    function deleteStorageData(value) {
        GM.deleteValue(value);
    }


})()